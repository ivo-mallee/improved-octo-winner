<?php
function RUN()
{
    @$userName = $_POST['UserName'];
    @$psw = $_POST['psw'];
    global $pdo;
    if (@$_POST) {
        $sth = $pdo->prepare("SELECT * FROM `users` WHERE `UserName` = '$userName' and `PassWordHash` = '$psw'"); //get the ImageNames and descriptions
        $sth->execute();
        $result = $sth->fetchAll(PDO::FETCH_ASSOC);
        if (@!$result) {
            echo "credentials are incorrect";
            return;
        }
        $_SESSION["UserName"] = $userName;
        $_SESSION["PSW"] = $psw;
    }
}
