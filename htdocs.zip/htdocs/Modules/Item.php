<?php
function RUN()
{
$PostArray = $_POST;
global $pdo;
global $params;
global $UserName;
global $SecurityLevel;
$ID  = $params[2];
$sth = $pdo->prepare("SELECT * FROM `categoryitems` WHERE `ID` = $ID"); //get the Item
$sth->execute();
$resultItem = $sth->fetchAll(PDO::FETCH_ASSOC);

if (@$PostArray) {
    
    $TempText = $PostArray['text'];
    $TempDesc = $PostArray['textarea'];
    $TempStarAmount = $PostArray['Stars'];
    $TemptextAuthor = $UserName;
    $sth = $pdo->prepare("INSERT INTO `reviews` (`ID`, `stars Amount`, `Description`, `Title`, `ItemID`,`author`) VALUES (NULL, '$TempStarAmount', '$TempDesc', '$TempText', '$ID','$TemptextAuthor');"); //send the review if a review is provided
    $sth->execute();
}


$sth = $pdo->prepare("SELECT * FROM `itemdescription` WHERE `CategoryItemID` =$ID"); //get the item description
$sth->execute();
$resultDesc = $sth->fetchAll(PDO::FETCH_ASSOC);
@$TEMP =$resultDesc[0]['ItemDescription'];
$resultItem[0]['ItemDesc'] = "$TEMP";
$TEMP = array(4);
$TEMP[0] = $resultItem;
$TEMP[1] = $ID;
$catagoryID = $resultItem[0]['categoryID'];




$sth = $pdo->prepare("SELECT * FROM `categories` WHERE `ID`= $catagoryID"); //get the Name of the catagory where the items are from
$sth->execute();
$result = $sth->fetchAll(PDO::FETCH_ASSOC);
$TEMP[2] = $result[0]['Name'];

$sth = $pdo->prepare("SELECT * FROM `reviews` WHERE `ItemID` = $ID"); //get the reviews
$sth->execute();
$ReviewArrayData = $sth->fetchAll(PDO::FETCH_ASSOC);
$reviews="";







if (count($ReviewArrayData) !=0) //if there are reviews
{
for ($i =0; $i< count($ReviewArrayData); $i++) 
    {
    $TempTitle=$ReviewArrayData[$i]['Title'];
    $TempDesc=$ReviewArrayData[$i]['Description'];
    $TempStarAmount = $ReviewArrayData[$i]['stars Amount'];
    $TempAuthor = $ReviewArrayData[$i]['author'];
    $Stars = "";
    for ($T =0; $T<$TempStarAmount; $T++) 
    {
        $Stars= "$Stars<img class='Review-star'>";
    }
    $reviews = "$reviews <div class='card'>
            <div class='card-header'>$TempAuthor</div>
            <div class='card-body'>
            <h5 class='card-title'>$TempTitle</h5>
            <p class='card-text'>
            $TempDesc
            </p>
            </div>
            <div class='card-footer'>$Stars</div>
            </div>";
    }
}
$TEMP[3] = $reviews;

return $TEMP;



}

