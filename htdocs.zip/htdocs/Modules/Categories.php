<?php
// TODO Zorg dat de methodes goed ingevuld worden met de juiste queries.

function RUN()
{
    global $pdo;
    $sth = $pdo->prepare("SELECT * FROM `categories`");
    $sth->execute();

    /* Fetch all of the remaining rows in the result set */


    $result = $sth->fetchAll(PDO::FETCH_ASSOC);
    $Cards = "";
    for ($i = 0; $i < count($result); $i++) {
        $TName = $result[$i]['Name'];
        $TId = $result[$i]['ID'];

        $Cards = "$Cards 
   <div class='col-sm-4 col-md-3'>
        <div class='card'>
        <div class='card-body text-center'>
            <a href='/Items/$TId'>
                <img class='product-img img-responsive center-block' src='../public/img/categories/$TName.jpg'/>
            </a>
            <div class='card-title mb-3'>$TName</div>
        </div>
        </div>
    </div>
    ";
    }
    return $Cards;
}
