<?php
function run() 
{
    global $pdo;
    $sth = $pdo->prepare("SELECT * FROM `tijden`"); //get the ImageNames and descriptions
    $sth->execute();
    $result = $sth->fetchAll(PDO::FETCH_ASSOC);
    $output = "";
    foreach($result as $i) 
    {
        $tempDay =$i['Day'];
        $tempTimes = $i['openings tijden'];
        $output = "$output<li>$tempDay $tempTimes</li>";
    }
    return $output;
}