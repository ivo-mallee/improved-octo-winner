<?php
// TODO Zorg dat de methodes goed ingevuld worden met de juiste queries.

function RUN()
{

    if (@$_POST) {
        $Email = $_POST['Email'];
        $Pass = $_POST['PassWord'];
        global $pdo;
        $hash = hash('sha256', $Pass);
        $hash = $Pass;
        $sth = $pdo->prepare("INSERT INTO `users` (`ID`, `UserName`, `SecurityLevel`, `PassWordHash`) VALUES (NULL, '$Email', '0', '$hash')"); //get the ImageNames and descriptions
        $sth->execute();
    }
}
