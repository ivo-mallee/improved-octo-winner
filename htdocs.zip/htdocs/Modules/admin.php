<?php

function getName($n) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $randomString = '';
  
    for ($i = 0; $i < $n; $i++) {
        $index = rand(0, strlen($characters) - 1);
        $randomString .= $characters[$index];
    }
  
    return $randomString;
}

function RUN()
{

    global $pdo;
    global $SecurityLevel;
    if ($SecurityLevel < 9) {
        echo '<script>window.location.href = "/home"; </script>';
        return "DISALLOWED";
    }


    if (@$_POST) {
        $tmp_name = $_FILES["IMG"]["tmp_name"];
        $Type = $_FILES["IMG"]["type"];
        $FileExtension = explode(".", $_FILES['IMG']["name"])[1];

        $tempName = $_POST['Name'];
        $tempID = $_POST['Category'];
        $TempImageName= getName(50);
        $sth = $pdo->prepare("SELECT Name FROM `categories` WHERE ID = $tempID");
        $sth->execute();
        $Location = $sth->fetchAll(PDO::FETCH_ASSOC);
        $Location = $Location[0]['Name'];
        $uploads_dir = "img/categories/Machine Images/$Location";


        $name = "$TempImageName.$FileExtension";
        move_uploaded_file($tmp_name, "$uploads_dir/$name");
        $tempDesc = "this was made via the crut table";
        $sth = $pdo->prepare("INSERT INTO `categoryitems` (`ID`, `Name`, `ItemDesc`, `categoryID`,`ImageName`) VALUES (NULL, '$tempName', 'InsertItemDescHere', '$tempID','$TempImageName');"); //get the Item
        $sth->execute();
    }





    $sth = $pdo->prepare("SELECT * FROM `categories`"); //get the categories
    $sth->execute();
    $categoriesInput = $sth->fetchAll(PDO::FETCH_ASSOC);


    $sth = $pdo->prepare("SELECT categories.Name AS 'category Name' ,categoryitems.Name,categoryitems.ItemDesc FROM `categoryitems` INNER JOIN categories ON categories.ID=categoryitems.categoryID;");
    $sth->execute();
    $TableResult = $sth->fetchAll(PDO::FETCH_ASSOC);

    $keys = array_keys($TableResult[0]);





    $Out = array();
    $categoriesList = array();

    $TableData = "";
    $FormCategories = "";

    $TableData = "$TableData <tr>";
    for ($i = 0; $i < count($keys); $i++) //create headers for table
    {
        $TempHeaderName =  $keys[$i];
        $TableData = "$TableData <th> $TempHeaderName </th>";
    }
    $TableData = "$TableData </tr>";



    for ($i = 0; $i < count($TableResult); $i++) //create Data for table
    {

        $TableData = "$TableData <tr>";
        for ($O = 0; $O < count($keys); $O++) //create headers for table
        {
            $TempKeyName =  $keys[$O];
            $TempData = $TableResult[$i][$TempKeyName];
            $TableData = "$TableData <td> $TempData </td>";
        }


        $TableData = "$TableData </tr>";
    }




    for ($i = 0; $i < count($categoriesInput); $i++) //create the options for the form
    {
        $tempName = $categoriesInput[$i]["Name"];
        $tempID = $categoriesInput[$i]["ID"];
        $FormCategories = "$FormCategories  <option value='$tempID'>$tempName</option>";
    }






    $Out['TableData'] = $TableData;
    $Out['FormCategories'] = $FormCategories;





    return $Out;
}
