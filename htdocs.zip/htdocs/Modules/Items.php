<?php


function RUN()
{
    global $pdo;
    global $params;
    $ID  = $params[2];
    $sth = $pdo->prepare("SELECT * FROM `categoryitems` WHERE `categoryID` = $ID"); //get the ImageNames and descriptions
    $sth->execute();

    /* Fetch all of the remaining rows in the result set */




    $result = $sth->fetchAll(PDO::FETCH_ASSOC);
    $Cards = "";

    $sth = $pdo->prepare("SELECT * FROM `categories` WHERE `ID`= $ID"); //get the Name of the catagory where the items are from
    $sth->execute();
    $Cresult = $sth->fetchAll(PDO::FETCH_ASSOC);
    $OUT = array(3);
    $OUT[1] = $Cresult[0]['Name'];
    for ($i = 0; $i < count($result); $i++) {
        $TName = $result[$i]['Name'];
        $TimageName=$result[$i]['ImageName'];
        $TId = $result[$i]['ID'];
        $CatagoryName = $OUT[1];
        //generate a card and repeat for every item
        $Cards = "$Cards 
   <div class='col-sm-4 col-md-3'>
        <div class='card'>
        <div class='card-body text-center'>
            <a href='/Item/$TId'>
                <img class='product-img img-responsive center-block' src='../public/img/categories/Machine Images/$CatagoryName/$TimageName.jpg'/>
            </a>
            <div class='card-title mb-3'>$TName</div>
        </div>
        </div>
    </div>
    ";
    }






    $OUT[0] = $Cards;
    $OUT[2] = $ID;
    return $OUT; //return the cards to the template



}
