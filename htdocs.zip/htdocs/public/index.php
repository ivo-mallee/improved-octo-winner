<?php
$request = $_SERVER['REQUEST_URI'];
$params = explode("/", $request);
$title = "OnlySport";
$titleSuffix = "";
require "../modules/Database.php";
session_start();



$SecurityLevel = 0;
@$UserName = $_SESSION["UserName"];
@$password = $_SESSION["PSW"];


$hash = $password;
//$hash=hash('sha256', $password);

$sth = $pdo->prepare("SELECT SecurityLevel FROM `users` WHERE `UserName` = '$UserName' AND `PassWordHash` = '$hash'"); //get the ImageNames and descriptions
$sth->execute();
$result = $sth->fetchAll(PDO::FETCH_ASSOC);
if (@$result) {
    $SecurityLevel = @$result[0]['SecurityLevel'];
} else {
    $UserName = "Guest";
}











$name = $params[1];
if (@include_once "../Modules/$name.php") {
    $DocInput = RUN();
    if ($DocInput == "DISALLOWED") {
        return;
    }
    include_once "../Templates/$name.php";
} else {
    include_once "../Templates/home.php";
}


function getTitle()
{
    global $title, $titleSuffix;
    return $title . $titleSuffix;
}
