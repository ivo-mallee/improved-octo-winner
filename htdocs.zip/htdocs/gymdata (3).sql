-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Gegenereerd op: 07 apr 2022 om 12:58
-- Serverversie: 10.4.22-MariaDB
-- PHP-versie: 8.0.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gymdata`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `categories`
--

CREATE TABLE `categories` (
  `ID` int(20) NOT NULL,
  `Name` varchar(16) NOT NULL,
  `description` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Gegevens worden geëxporteerd voor tabel `categories`
--

INSERT INTO `categories` (`ID`, `Name`, `description`) VALUES
(1, 'dumbells', 'Dumbells for training of biceps'),
(2, 'rowingMachines', 'Rowing Machines for all your rowing needs'),
(18, 'Weights', 'General Purpose Weights'),
(19, 'Treadmills', 'Treadmill for all your running needs');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `categoryitems`
--

CREATE TABLE `categoryitems` (
  `ID` int(8) NOT NULL,
  `Name` varchar(90) NOT NULL,
  `ItemDesc` varchar(400) NOT NULL,
  `categoryID` int(8) NOT NULL,
  `ImageName` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Gegevens worden geëxporteerd voor tabel `categoryitems`
--

INSERT INTO `categoryitems` (`ID`, `Name`, `ItemDesc`, `categoryID`, `ImageName`) VALUES
(2, 'Roeitrainer - Focus Fitness Row 2\n', 'Perfect voor naar muziek luisteren', 2, 'Roeitrainer - Focus Fitness Row 2'),
(4, 'f', 'f', 18, 'f'),
(6, 'Roeitrainer - Focus Fitness Row 3', 'Perfect voor naar muziek luisteren', 2, 'Roeitrainer - Focus Fitness Row 3'),
(7, 'Roeitrainer - Senz Sports R4000 - Waterroeitrainer\n', 'Perfect voor naar muziek luisteren', 2, 'Roeitrainer - Senz Sports R4000 - Waterroeitrainer'),
(8, 'Weight 10kg', '10kg Weight ', 18, 'Weight 10kg'),
(9, 'Weight 15kg', '15kg Weight ', 18, 'Weight 15kg'),
(10, 'Weight 20kg', '20kg Weight ', 18, 'Weight 20kg'),
(11, 'Weight 25kg', '25kg Weight ', 18, 'Weight 25kg'),
(15, 'Dumbbell Hexagon - 1 kg\r\n', '1kg Dumbell', 1, 'Dumbbell Hexagon - 1 kg'),
(16, 'Dumbbell Hexagon - 10 kg\r\n', '10kg Dumbell', 1, 'Dumbbell Hexagon - 10 kg'),
(17, 'Dumbbell Hexagon - 20 kg\r\n', '20kg Dumbell', 1, 'Dumbbell Hexagon - 20 kg'),
(18, '250\r\n', '25kg Dumbell', 1, '250'),
(20, 'Loopband - Focus Fitness Jet 7', 'LoopBand perfect voor LoopBand Dingen', 19, 'Loopband - Focus Fitness Jet 7'),
(21, 'TUNTURI TREADMILL FITRUN 40I\r\n', 'LoopBand perfect voor LoopBand Dingen', 19, 'TUNTURI TREADMILL FITRUN 40I'),
(111, 'testt', 'InsertItemDescHere', 1, 'testt'),
(112, 'Image Test', 'InsertItemDescHere', 1, 'Image Test'),
(113, 'fsdfdf', 'InsertItemDescHere', 18, 'U9TQCwdhjzFB7qQAYDp13yzlsq2O99nIX2Hfxz4WcueLkE7WuC'),
(114, 'ggg', 'InsertItemDescHere', 2, 'WL1KNEqP2jJPLg8gGNHlOufLHIOnvq0lHo9iDM2YNQzAPeo2t0');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `itemdescription`
--

CREATE TABLE `itemdescription` (
  `ID` int(20) NOT NULL,
  `ItemDescription` text NOT NULL,
  `CategoryItemID` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `reviews`
--

CREATE TABLE `reviews` (
  `ID` int(255) NOT NULL,
  `author` varchar(16) NOT NULL,
  `stars Amount` int(2) NOT NULL,
  `Description` text NOT NULL,
  `Title` text NOT NULL,
  `ItemID` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Gegevens worden geëxporteerd voor tabel `reviews`
--

INSERT INTO `reviews` (`ID`, `author`, `stars Amount`, `Description`, `Title`, `ItemID`) VALUES
(39, 'ivo mallee', 1, 'ff', 'author', 6),
(40, 'Guest', 1, 'dgdfg', 'gsdfg', 2),
(41, 'admin', 1, 'dsfdf', 'sdfsdf', 9),
(42, 'Guest', 1, 'sdf', 'sdf', 15);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `tijden`
--

CREATE TABLE `tijden` (
  `id` int(9) NOT NULL,
  `Day` varchar(24) NOT NULL,
  `openings tijden` varchar(24) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Gegevens worden geëxporteerd voor tabel `tijden`
--

INSERT INTO `tijden` (`id`, `Day`, `openings tijden`) VALUES
(2, 'maandag', '7:00-20:00'),
(3, 'dinsdag', '8:00-20:00'),
(4, 'woensdag', '7:00-20:00'),
(5, 'donderdag', '8:00-20:00'),
(6, 'vrijdag', '7:00-20:30'),
(7, 'zaterdag', '8:00-1:00'),
(8, 'zondag', '8:00-1:00');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `users`
--

CREATE TABLE `users` (
  `ID` int(16) NOT NULL,
  `UserName` varchar(64) NOT NULL,
  `SecurityLevel` int(1) NOT NULL,
  `PassWordHash` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Gegevens worden geëxporteerd voor tabel `users`
--

INSERT INTO `users` (`ID`, `UserName`, `SecurityLevel`, `PassWordHash`) VALUES
(1, 'ivo', 9, 'mallee'),
(22, 'ivomallee', 0, 'test'),
(23, 'admin', 9, 'admin');

--
-- Indexen voor geëxporteerde tabellen
--

--
-- Indexen voor tabel `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`ID`);

--
-- Indexen voor tabel `categoryitems`
--
ALTER TABLE `categoryitems`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `Category-Item-Category-Binding` (`categoryID`);

--
-- Indexen voor tabel `itemdescription`
--
ALTER TABLE `itemdescription`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ItemDescription-Item-Binding` (`CategoryItemID`);

--
-- Indexen voor tabel `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `Description-item-link` (`ItemID`);

--
-- Indexen voor tabel `tijden`
--
ALTER TABLE `tijden`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT voor geëxporteerde tabellen
--

--
-- AUTO_INCREMENT voor een tabel `categories`
--
ALTER TABLE `categories`
  MODIFY `ID` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT voor een tabel `categoryitems`
--
ALTER TABLE `categoryitems`
  MODIFY `ID` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=115;

--
-- AUTO_INCREMENT voor een tabel `itemdescription`
--
ALTER TABLE `itemdescription`
  MODIFY `ID` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT voor een tabel `reviews`
--
ALTER TABLE `reviews`
  MODIFY `ID` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT voor een tabel `tijden`
--
ALTER TABLE `tijden`
  MODIFY `id` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT voor een tabel `users`
--
ALTER TABLE `users`
  MODIFY `ID` int(16) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- Beperkingen voor geëxporteerde tabellen
--

--
-- Beperkingen voor tabel `categoryitems`
--
ALTER TABLE `categoryitems`
  ADD CONSTRAINT `Category-Item-Category-Binding` FOREIGN KEY (`categoryID`) REFERENCES `categories` (`ID`);

--
-- Beperkingen voor tabel `itemdescription`
--
ALTER TABLE `itemdescription`
  ADD CONSTRAINT `ItemDescription-Item-Binding` FOREIGN KEY (`CategoryItemID`) REFERENCES `categoryitems` (`ID`);

--
-- Beperkingen voor tabel `reviews`
--
ALTER TABLE `reviews`
  ADD CONSTRAINT `Description-item-link` FOREIGN KEY (`ItemID`) REFERENCES `categoryitems` (`ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
