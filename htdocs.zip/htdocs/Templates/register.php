<!DOCTYPE html>
<html>
<?php
include_once('defaults/head.php');
global $DocInput;

?>
<body>

<div class="container">
    <?php
    include_once('defaults/header.php');
    include_once('defaults/menu.php');
    include_once('defaults/pictures.php');
    ?>

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="/home">Home</a></li>
            <li class="breadcrumb-item"><a href="/categories">Categories</a></li>
        </ol>
    </nav>


<form class="form-horizontal" method="post">
<fieldset>

<!-- Form Name -->
<legend>Form Name</legend>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="Email">UserName</label>  
  <div class="col-md-4">
  <input id="Email" name="Email" type="text" placeholder="We won't share this with anyone else " class="form-control input-md" required="">
  <span class="help-block">Input your Email Here</span>  
  </div>
</div>

<!-- Password input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="PassWord">Password</label>
  <div class="col-md-4">
    <input id="PassWord" name="PassWord" type="password" placeholder="Please use a secure passsword" class="form-control input-md" required="">
    <span class="help-block">Input your password here</span>
  </div>
</div>

<!-- Button -->
<div class="form-group">
  <label class="col-md-4 control-label" for="SUBMIT"></label>
  <div class="col-md-4">
    <button class="btn btn-success">Make Account</button>
  </div>
</div>

</fieldset>
</form>


    
    <hr>
    <?php
    include_once('defaults/footer.php');

    ?>
</div>

</body>
</html>

