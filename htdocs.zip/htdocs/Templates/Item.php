<!DOCTYPE html>
<html>
<?php
include_once('defaults/head.php');
global $DocInput;
?>
<body>

<div class="container">
    <?php
    include_once('defaults/header.php');
    include_once('defaults/menu.php');
    include_once('defaults/pictures.php');
    ?>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="/home">Home</a></li>
            <li class="breadcrumb-item"><a href="/categories">Categories</a></li>
            <li class="breadcrumb-item"><a href="/categories"><?php echo $DocInput[2]; ?></a></li>
            <li class="breadcrumb-item"><a href="/Item/<?php echo $DocInput[2]; ?>"><?php echo $DocInput[0][0]['Name']; ?></a></li>
        </ol>
    </nav>
    
    <h1 class="Product-page-title"> <?php echo $DocInput[0][0]['Name']; ?> </h1>
    <img src="../public/img/categories/Machine Images/<?php echo $DocInput[2]; ?>/<?php echo $DocInput[0][0]['Name'];?>.jpg" style="width: 20vw;   display: block;margin-left: auto; margin-right: auto;">
    <div class="Product-page-desc"> <?php echo $DocInput[0][0]['ItemDesc']; ?> </div>


<form method="post"> <!--Review Form --> 
  <div class="form-group">
    <label for="Stars">Stars</label> 
    <div>
      <select id="Stars" name="Stars" required="required" class="custom-select">
        <option value="1">1 Star</option>
        <option value="2">2 Stars</option>
        <option value="3">3 Stars</option>
        <option value="4">4 Stars</option>
        <option value="5">5 Stars</option>
      </select>
    </div>
  </div>
  <div class="form-group">
    <label for="InTitle">ReviewTitle</label> 
    <input id="text" name="text" type="text" class="form-control">
  </div>
  <div class="form-group">
    <label for="InDesc">Review Contents</label> 
    <textarea id="textarea" name="textarea" cols="40" rows="5" class="form-control"></textarea>
  </div> 
  <div class="form-group">
    <br>
    <button name="submit" type="submit" class="btn btn-primary">Submit</button>
</div>
</form>
<br>

    


    


    <div class="row gy-3 ">


    <?php echo $DocInput[3] ?>
    </div>
    
  



    <hr>
    <?php
    include_once('defaults/footer.php');

    ?>
</div>

</body>
</html>

