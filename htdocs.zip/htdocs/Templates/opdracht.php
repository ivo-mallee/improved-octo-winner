<?php 

$servername = "localhost";
$username = "root";
$password = "";

try {
  $conn = new PDO("mysql:host=$servername;dbname=opdracht", $username, $password);
  // set the PDO error mode to exception
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  echo "Connected successfully";
} catch(PDOException $e) {
  echo "Connection failed: " . $e->getMessage();
}

$querry = $conn->prepare("SELECT * FROM `cars`");
$querry->execute();
$result = $querry->FetchAll(PDO::FETCH_ASSOC);

$listData = "";
for ($i =0; $i< count($result); $i++) 
{
  $TempPrice = $result[$i]['Price'];
  $TempKms = $result[$i]['KMs'];
  $TempName = $result[$i]['Name'];
  
  
  
  
  $listData = "$listData
  <tr>
  <td>$TempName </td>
  <td>$TempKms KM</td>
  <td>$TempPrice Euro</td>
  </tr>
  ";
}







?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
    <!DOCTYPE html>
<html>
<head>
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
</head>
<body>

<h2>HTML Table</h2>

<table>
  <tr>
    <th>Name</th>
    <th>Range</th>
    <th>Price</th>
  </tr>
  <?= $listData ?>

</table>

</body>
</html>




</body>
</html>