<!DOCTYPE html>
    <html>
    <?php
    include_once('defaults/head.php');
    global $DocInput;
    ?>
    <body>
        <div class="container">
            <?php
            include_once ('defaults/header.php');
            include_once ('defaults/menu.php');
            include_once ('defaults/pictures.php');
            ?>








            <form method="post" action="login" autocomplete="off">
            <div class="form-group row">
                <label for="UserName" class="col-1 col-form-label">UserName</label> 
                <div class="col-6">
                <input id="UserName" name="UserName" type="text" class="form-control">
                </div>
            </div>
            <br>
            <div class="form-group row">
                <label for="psw" class="col-1 col-form-label">Password</label> 
                <div class="col-6">
                <input id="psw" name="psw" type="password" class="form-control">
                </div>
            </div> 
            <br>
            <div class="form-group row">
                <div class="offset-1 col-6">
                <button name="submit" type="submit" class="btn btn-primary">Submit</button>
                </div>
            </div>
            </form>



            <hr>
            <?php
            include_once ('defaults/footer.php');
            ?>
        </div>
    </body>
</html>
