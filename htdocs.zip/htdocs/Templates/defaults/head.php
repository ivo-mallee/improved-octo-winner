<?php global $SecurityLevel;?>


<head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <title><?= getTitle() ?></title>
    <link rel="stylesheet" href="/css/bootstrap.min.css"/>
    
    <?php if ($SecurityLevel !=9) {echo "<style>.AdminItem{display: none;}</style>";}?>
    <script src="/js/bootstrap.bundle.js"></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="/css/style.css"/>
</head>