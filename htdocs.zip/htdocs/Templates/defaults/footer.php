<footer >
    <p class="clearfix pb-3  text-muted text-center">&copy;Gemaakt door Ivo Mallee.</p>
</footer>
