<figure>
    <img class="banner-img img-fluid" src='/img/healthone-wide.png' />
</figure>


