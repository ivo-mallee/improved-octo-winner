<!DOCTYPE html>
<?php
global $DocInput;
?>

<html>
<?php
include_once('defaults/head.php');
?>

<body>
    <div class="container">
        <?php
        include_once('defaults/header.php');
        include_once('defaults/menu.php');
        include_once('defaults/pictures.php');
        ?>


        <form method="post" action="/admin" enctype="multipart/form-data">
            <div class="form-group row">
                <label for="Name" class="col-2 col-form-label">Name</label>
                <div class="col-10">
                    <input id="Name" name="Name" type="text" required="required" class="form-control">
                </div>
            </div>



            <div class="form-group row">
                <label for="Category" class="col-2 col-form-label">Category</label>
                <div class="col-10">
                    <select id="Category" name="Category" required="required" class="custom-select">
                        <?php echo $DocInput['FormCategories'] ?>
                    </select>
                </div>
            </div>
            <div class="form-group row">
                <label for="Image" class="col-2 col-form-label">Name</label>
                <div class="col-10">
                    <input name="IMG" type="file" required="required" accept="image/png, image/jpeg" class="form-control">
                </div>
            </div>





            <div class="form-group row">
                <div class="offset-2 col-10">
                    <button name="submit" type="submit" class="btn btn-primary">Submit</button>
                </div>
            </div>
        </form>
        <br>
        <br>
        <table style="width: 100%;" class="table table-bordered""> 
                    
                    <?php echo $DocInput['TableData']; ?>
                
                </table>
    

          
               

     



        

            







            <hr>
            <?php
            include_once('defaults/footer.php');
            ?>
        </div>
    </body>
</html>